import json
import sys
from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED

fabric, remapped, classes, resources, refmap, target = map(Path, sys.argv[1:])
adapted_data = {p.relative_to(resources).as_posix(): p for folder in ('assets', 'data') for p in (resources / folder).rglob('*.json')}
for spec in resources.glob('*.tsv'):
    adapted_data[spec.name] = spec
compiled = {p.relative_to(classes).as_posix(): p for p in classes.rglob('*.class')}
with ZipFile(fabric) as original, ZipFile(remapped) as code, ZipFile(target, 'w', ZIP_DEFLATED) as result:
    for name in original.namelist():
        if name.endswith('/'):
            continue
        if (name.startswith(('assets/', 'data/')) or 'LICENSE' in name.upper()) and name not in adapted_data:
            result.writestr(name, original.read(name))
    for name, path in adapted_data.items():
        result.write(path, name)
    for name in code.namelist():
        if name.endswith('.class') and name not in compiled:
            result.writestr(name, code.read(name))
    for name, path in compiled.items():
        result.write(path, name)
    result.writestr('META-INF/MANIFEST.MF', 'Manifest-Version: 1.0\r\nMixinConfigs: chestcavity.mixins.json\r\n\r\n')
    result.write(resources / 'mods.toml', 'META-INF/mods.toml')
    result.write(resources / 'pack.mcmeta', 'pack.mcmeta')
    for name in ('LICENSE-CC0.txt', 'NOTICE.txt'):
        result.write(resources / name, name)
    mixins = json.loads(original.read('chestcavity.mixins.json'))
    mixins['mixins'].extend(['ButcheryCarcassMixin', 'ButcheryDeathMixin', 'ButcheryLootMixin', 'CarcassPlacementMixin', 'CarcassBlockChangesMixin', 'ElderGuardianCarcassMixin', 'HeartScoreMixin'])
    mixins['refmap'] = refmap.name
    result.writestr('chestcavity.mixins.json', json.dumps(mixins, indent=2) + '\n')
    result.write(refmap, refmap.name)
