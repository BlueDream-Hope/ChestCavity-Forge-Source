import json
import re
import sys
from pathlib import Path
from zipfile import ZipFile

inputs, mod, output = map(Path, sys.argv[1:])
with ZipFile(inputs / 'intermediary.jar') as archive:
    tiny = archive.read('mappings/mappings.tiny').decode().splitlines()[1:]
classes = {parts[1]: parts[2] for row in tiny if row.startswith('c\t') for parts in [row.split('\t')]}
current = None
for row in (inputs / 'vanilla-to-srg.tsrg').read_text().splitlines()[1:]:
    if not row.startswith('\t'):
        current, name = row.split()
        classes.setdefault(current, name)
obf = {}
srg_classes = {}
for row in (inputs / 'vanilla-to-srg.tsrg').read_text().splitlines()[1:]:
    if not row.startswith('\t'):
        current, name = row.split()
        srg_classes[current] = name
    elif not row.startswith('\t\t'):
        parts = row.split()
        if len(parts) == 2:
            obf[current, parts[0], ''] = parts[1]
        elif len(parts) == 3:
            obf[current, parts[0], parts[1]] = parts[2]
member_by_id = {}
scoped_methods = {}
with output.open('w') as out:
    for row in tiny:
        parts = row.strip().split('\t')
        if parts[0] == 'c':
            current, intermediary = parts[1:]
            name = srg_classes.get(current)
            if name:
                print('c', intermediary, name, sep='\t', file=out)
        elif parts[0] in ('f', 'm') and current in srg_classes:
            kind, desc, original, id_ = parts
            named = obf.get((current, original, '' if kind == 'f' else desc))
            if not named:
                continue
            mapped_desc = re.sub(r'L([^;]+);', lambda m: 'L' + classes.get(m[1], m[1]) + ';', desc)
            print(kind, intermediary, id_, mapped_desc, named, sep='\t', file=out)
            member_by_id[id_, mapped_desc] = named
            scoped_methods[intermediary, id_, mapped_desc] = named

    for (original_owner, name, desc), mapped in obf.items():
        if desc and len(name) > 2 and not name.startswith('<') and name != mapped:
            owner = classes[original_owner]
            mapped_desc = re.sub(r'L([^;]+);', lambda m: 'L' + classes.get(m[1], m[1]) + ';', desc)
            print('sam', owner, name, mapped_desc, mapped, sep='\t', file=out)

    # Loom preserves some named functional-interface lambda names.
    with ZipFile(inputs / 'yarn.jar') as archive:
        for row in archive.read('mappings/mappings.tiny').decode().splitlines()[1:]:
            if row.startswith('c\t'):
                owner = row.split('\t')[1]
            elif row.startswith('\tm\t'):
                _, _, desc, intermediary, yarn = row.split('\t')[:5]
                name = scoped_methods.get((owner, intermediary, desc))
                if name and yarn != intermediary:
                    print('sam', owner, yarn, desc, name, sep='\t', file=out)

with ZipFile(mod) as archive:
    refmap = json.loads(archive.read('chestcavity-refmap.json'))
for group in refmap['mappings'].values():
    for key, value in group.items():
        owner, name, desc = re.fullmatch(r'L([^;]+);([^\(]+)(\(.*)', value).groups()
        target_owner = next((srg_classes.get(obf_name, owner) for obf_name, inter in classes.items() if inter == owner), owner)
        group[key] = [target_owner, member_by_id.get((name, desc), name), desc]
reverse = {inter: srg_classes[original] for original, inter in classes.items() if original in srg_classes}
for group in refmap['mappings'].values():
    for key, (owner, name, desc) in group.items():
        desc = re.sub(r'L([^;]+);', lambda m: 'L' + reverse.get(m[1], m[1]) + ';', desc)
        group[key] = f'L{owner};{name}{desc}'
refmap['data'] = {}
output.with_name('chestcavity-forge-refmap.json').write_text(json.dumps(refmap, indent=2) + '\n')
