import java.io.*;
import java.nio.file.*;
import java.util.*;
import java.util.jar.*;
import org.objectweb.asm.*;
import org.objectweb.asm.commons.*;
import org.objectweb.asm.tree.*;

public class Remap extends Remapper {
    private final Map<String, String> classes = new HashMap<>();
    private final Map<String, String> fields = new HashMap<>();
    private final Map<String, String> methods = new HashMap<>();
    private final Map<String, String> samMethods = new HashMap<>();
    private final Set<String> ambiguous = new HashSet<>();
    private final Set<String> remove = Set.of("ChestCavity", "ChestCavityClient", "ChestCavityServer",
        "registration/CCNetworkingPackets", "registration/CCCommands", "config/CCModMenuIntegration",
        "util/NetworkUtil", "listeners/LootTableListeners", "mixin/MixinHungerManager");
    private static final String MOD = "net/tigereye/chestcavity/";
    private static final String FABRIC = "net/fabricmc/fabric/api/";

    Remap(Path mapping) throws IOException {
        for (String line : Files.readAllLines(mapping)) {
            String[] value = line.split("\t");
            if (value[0].equals("c")) {
                classes.put(value[1], value[2]);
                continue;
            }
            if (value[0].equals("sam")) {
                samMethods.put(value[1] + "#" + value[2] + value[3], value[4]);
                continue;
            }
            Map<String, String> members = value[0].equals("f") ? fields : methods;
            String previous = members.putIfAbsent(value[2], value[4]);
            if (previous != null && !previous.equals(value[4])) {
                ambiguous.add(value[2]);
            }
            members.put(value[1] + "#" + value[2] + value[3], value[4]);
            members.put(value[2] + value[3], value[4]);
        }
        classes.put(FABRIC + "event/Event", MOD + "forge/CallbackEvent");
        classes.put(FABRIC + "event/EventFactory", MOD + "forge/CallbackEvent");
        classes.put(FABRIC + "itemgroup/v1/FabricItemGroup", "net/minecraft/world/item/CreativeModeTab");
        classes.put(FABRIC + "resource/SimpleSynchronousResourceReloadListener",
            "net/minecraft/server/packs/resources/ResourceManagerReloadListener");
        classes.put(FABRIC + "registry/FuelRegistry", MOD + "forge/FurnaceFuel");
        classes.put(FABRIC + "client/keybinding/v1/KeyBindingHelper", MOD + "forge/client/ClientEvents");
        classes.put(FABRIC + "client/event/lifecycle/v1/ClientTickEvents", MOD + "forge/client/ClientEvents");
        classes.put(FABRIC + "client/event/lifecycle/v1/ClientTickEvents$EndTick", MOD + "forge/client/ClientEvents$EndTick");
    }

    @Override public String map(String name) {
        return classes.getOrDefault(name, name);
    }

    @Override public String mapFieldName(String owner, String name, String descriptor) {
        return member(fields, owner, name, descriptor);
    }

    @Override public String mapMethodName(String owner, String name, String descriptor) {
        return member(methods, owner, name, descriptor);
    }

    @Override public String mapInvokeDynamicMethodName(String name, String descriptor) {
        return ambiguous.contains(name) ? name : methods.getOrDefault(name, name);
    }

    private String member(Map<String, String> members, String owner, String name, String descriptor) {
        return members.getOrDefault(owner + "#" + name + descriptor,
            members.getOrDefault(name + descriptor, ambiguous.contains(name) ? name : members.getOrDefault(name, name)));
    }

    private void process(JarFile source, JarOutputStream target) throws IOException {
        for (JarEntry entry : Collections.list(source.entries())) {
            String name = entry.getName();
            if (!name.endsWith(".class") || !name.startsWith(MOD)) continue;
            String local = name.substring(MOD.length(), name.length() - 6);
            if (remove.contains(local) || local.startsWith("compat/") || local.equals("mixin/MixinSlot")) continue;
            ClassNode node = new ClassNode();
            try (InputStream stream = source.getInputStream(entry)) {
                new ClassReader(stream).accept(node, local.equals("mixin/MixinLivingEntity") ? ClassReader.SKIP_FRAMES : 0);
            }
            if (node.invisibleAnnotations != null) {
                node.invisibleAnnotations.removeIf(ann -> ann.desc.equals("Lnet/fabricmc/api/Environment;"));
            }
            if (local.equals("registration/CCItems")) {
                node.methods.removeIf(method -> method.name.equals("register") || method.name.equals("registerItem")
                    || method.name.equals("registerItemGroups") || method.name.startsWith("lambda$registerItemGroups"));
            }
            boolean rewriteTooltips = local.equals("util/OrganUtil");
            if (rewriteTooltips) {
                for (MethodNode method : node.methods) {
                    if (!method.name.equals("displayCompatibility")) continue;
                    method.instructions.clear();
                    method.tryCatchBlocks.clear();
                    method.localVariables = null;
                    method.invisibleAnnotations = null;
                    for (int slot = 0; slot < 4; slot++) {
                        method.instructions.add(new VarInsnNode(Opcodes.ALOAD, slot));
                    }
                    method.instructions.add(new MethodInsnNode(Opcodes.INVOKESTATIC,
                        MOD + "forge/client/LocalizedTooltips", "displayCompatibility", method.desc, false));
                    method.instructions.add(new InsnNode(Opcodes.RETURN));
                }
            }
            if (local.equals("mixin/MixinLivingEntity$Server")) {
                node.methods.removeIf(method -> method.name.equals("chestCavityEntityMoveToWorldMixin"));
            }
            if (local.equals("mixin/MixinLivingEntity")) {
                for (MethodNode method : node.methods) {
                    if (!method.name.equals("chestCavityLivingEntityApplyFoodEffectsMixin")) continue;
                    method.desc = method.desc.replaceFirst("Ljava/util/List;", "Lnet/minecraft/class_4174;");
                    method.signature = null;
                    VarInsnNode load = new VarInsnNode(Opcodes.ALOAD, 1);
                    method.instructions.insert(load);
                    InsnList getEffects = new InsnList();
                    getEffects.add(new MethodInsnNode(Opcodes.INVOKEVIRTUAL, "net/minecraft/class_4174",
                        "m_38749_", "()Ljava/util/List;", false));
                    getEffects.add(new VarInsnNode(Opcodes.ASTORE, 1));
                    method.instructions.insert(load, getEffects);
                    AnnotationNode redirect = new AnnotationNode("Lorg/spongepowered/asm/mixin/injection/Redirect;");
                    AnnotationNode at = new AnnotationNode("Lorg/spongepowered/asm/mixin/injection/At;");
                    at.values = List.of("value", "INVOKE", "target",
                        "Lnet/minecraft/world/food/FoodProperties;m_38749_()Ljava/util/List;");
                    redirect.values = List.of("method", List.of("applyFoodEffects"), "at", at);
                    method.visibleAnnotations = List.of(redirect);
                }
            }
            if (local.endsWith("Manager")) {
                for (MethodNode method : node.methods) {
                    if (method.name.equals("reload") && method.desc.equals("(Lnet/minecraft/class_3300;)V")) {
                        method.name = "m_6213_";
                    }
                }
            }
            for (MethodNode method : node.methods) {
                for (AbstractInsnNode instruction : method.instructions) {
                    if (instruction instanceof InvokeDynamicInsnNode indy
                            && indy.bsm.getOwner().equals("java/lang/invoke/LambdaMetafactory")) {
                        String owner = Type.getReturnType(indy.desc).getInternalName();
                        String descriptor = ((Type) indy.bsmArgs[0]).getDescriptor();
                        indy.name = samMethods.getOrDefault(owner + "#" + indy.name + descriptor,
                            mapMethodName(owner, indy.name, descriptor));
                    }
                }
            }
            ClassWriter writer = new ClassWriter(rewriteTooltips ? ClassWriter.COMPUTE_MAXS : 0);
            node.accept(new ClassRemapper(writer, this));
            target.putNextEntry(new JarEntry(name));
            target.write(writer.toByteArray());
            target.closeEntry();
        }
    }

    public static void main(String[] args) throws IOException {
        Remap remapper = new Remap(Path.of(args[0]));
        try (JarFile source = new JarFile(args[1]); JarOutputStream target =
                new JarOutputStream(Files.newOutputStream(Path.of(args[2])))) {
            remapper.process(source, target);
        }
    }
}
