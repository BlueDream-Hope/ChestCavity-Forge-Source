#!/usr/bin/env python3
"""Build the Forge port using an installed Forge server and upstream artifacts."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
from urllib.request import urlopen
from zipfile import ZipFile

ROOT = Path(__file__).resolve().parent
CACHE = ROOT / 'build' / 'inputs'
FORGE = '1.20.1-47.4.0'
FILE = 'chestcavity-2.17.2.1-forge-1.20.1.jar'
FABRIC_HASH = '1c5d01b10cc514dc0bfc80a0c226fed488aea68bcff2340dbf8c2a943b08fd4e'
LIBRARIES = {
    'intermediary.jar': 'https://maven.fabricmc.net/net/fabricmc/intermediary/1.20.1/intermediary-1.20.1-v2.jar',
    'yarn.jar': 'https://maven.fabricmc.net/net/fabricmc/yarn/1.20.1+build.10/yarn-1.20.1+build.10-v2.jar',
    'art.jar': 'https://maven.neoforged.net/releases/net/neoforged/AutoRenamingTool/2.0.17/AutoRenamingTool-2.0.17-all.jar',
    'mcp.zip': 'https://maven.minecraftforge.net/de/oceanlabs/mcp/mcp_config/1.20.1-20230612.114412/mcp_config-1.20.1-20230612.114412.zip',
}

def fetch(url, target, sha1=None):
    if target.is_file() and (sha1 is None or hashlib.sha1(target.read_bytes()).hexdigest() == sha1):
        return target
    temporary = target.with_suffix('.download')
    with urlopen(url, timeout=60) as remote, temporary.open('wb') as output:
        shutil.copyfileobj(remote, output)
    if sha1 and hashlib.sha1(temporary.read_bytes()).hexdigest() != sha1:
        raise ValueError(f'Checksum mismatch for {target.name}')
    temporary.replace(target)
    return target

def run(*args):
    subprocess.run([str(arg) for arg in args], cwd=ROOT, check=True)

def get_jdk_tool(name):
    if os.getenv('JAVA_HOME'):
        return Path(os.environ['JAVA_HOME']) / 'bin' / name
    return name

def generate_mappings(mcp, mojang):
    classes = {}
    for line in mojang.read_text().splitlines():
        match = re.fullmatch(r'([^ #]+) -> (\S+):', line)
        if match:
            classes[match[2].replace('.', '/')] = match[1].replace('.', '/')
    lines = ['tsrg2 obf srg']
    with ZipFile(mcp) as archive:
        for line in archive.read('config/joined.tsrg').decode().splitlines()[1:]:
            if line.startswith('\t\t'):
                continue
            if line.startswith('\t'):
                lines.append(line.rsplit(' ', 1)[0])
            else:
                obfuscated, fallback, _ = line.split()
                lines.append(f'{obfuscated} {classes.get(obfuscated, fallback)}')
    (CACHE / 'vanilla-to-srg.tsrg').write_text('\n'.join(lines) + '\n')

def prepare_client(java):
    mapping = CACHE / 'vanilla-to-srg.tsrg'
    client = CACHE / 'client-srg.jar'
    if mapping.is_file() and client.is_file():
        return client
    catalog = fetch('https://piston-meta.mojang.com/mc/game/version_manifest_v2.json',
                    CACHE / 'version_manifest_v2.json')
    release = next(v for v in json.loads(catalog.read_bytes())['versions'] if v['id'] == '1.20.1')
    info = fetch(release['url'], CACHE / 'minecraft-1.20.1.json', release['sha1'])
    downloads = json.loads(info.read_bytes())['downloads']
    raw = {}
    for key, filename in [('client', 'minecraft-client.jar'), ('client_mappings', 'client-mappings.txt')]:
        raw[key] = fetch(downloads[key]['url'], CACHE / filename, downloads[key]['sha1'])
    generate_mappings(fetch(LIBRARIES['mcp.zip'], CACHE / 'mcp.zip'), raw['client_mappings'])
    run(java, '-jar', fetch(LIBRARIES['art.jar'], CACHE / 'art.jar'), '--input', raw['client'],
        '--output', client, '--map', mapping, '--threads', '3', '--ann-fix', '--record-fix',
        '--ids-fix', '--src-fix')
    return client

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--forge-server', type=Path, required=True, help='directory of the installed Forge server')
    parser.add_argument('--fabric-jar', type=Path, required=True, help='original Chest Cavity 2.17.2.1 jar')
    parser.add_argument('--cloth-jar', type=Path, required=True, help='cloth-config-11.1.136-forge.jar')
    options = parser.parse_args()
    fabric, cloth = options.fabric_jar.resolve(), options.cloth_jar.resolve()
    if hashlib.sha256(fabric.read_bytes()).hexdigest() != FABRIC_HASH:
        parser.error('The upstream Fabric JAR does not match the release used for this port.')
    if not cloth.is_file():
        parser.error('The Cloth Config Forge JAR was not found.')
    libraries = options.forge_server.resolve() / 'libraries'
    server = libraries / 'net/minecraftforge/forge' / FORGE / f'forge-{FORGE}-server.jar'
    if not server.is_file():
        parser.error(f'Install Forge Server {FORGE} first. Missing {server}')
    asm = [p for artifact in ('asm', 'asm-tree', 'asm-commons') for p in
           (libraries / 'org/ow2/asm' / artifact / '9.7.1').glob('*.jar')]
    if len(asm) != 3:
        parser.error('ASM 9.7.1 is missing from the Forge server installation.')
    CACHE.mkdir(parents=True, exist_ok=True)
    java, javac = get_jdk_tool('java'), get_jdk_tool('javac')
    for name in ('intermediary.jar', 'yarn.jar'):
        fetch(LIBRARIES[name], CACHE / name)
    client = prepare_client(java)
    work = ROOT / 'build'
    mapping, refmap = CACHE / 'intermediary-srg.tsv', CACHE / 'chestcavity-forge-refmap.json'
    remapped = work / 'remapped.jar'
    classes, tool_classes = work / 'classes', work / 'tools'
    for directory in (classes, tool_classes):
        if directory.exists():
            shutil.rmtree(directory)
        directory.mkdir()
    tools = ROOT / 'tools'
    run(sys.executable, tools / 'mappings.py', CACHE, fabric, mapping)
    asm_cp = os.pathsep.join(map(str, asm))
    run(javac, '--release', '17', '-cp', asm_cp, '-d', tool_classes, tools / 'Remap.java')
    run(java, '-cp', asm_cp + os.pathsep + str(tool_classes), 'Remap', mapping, fabric, remapped)
    classpath = os.pathsep.join(map(str, [server, client, cloth, remapped, *sorted(libraries.rglob('*.jar'), reverse=True)]))
    run(javac, '--release', '17', '-proc:none', '-cp', classpath, '-d', classes,
        *sorted((ROOT / 'src/main/java').rglob('*.java')))
    target = work / FILE
    run(sys.executable, tools / 'package.py', fabric, remapped, classes, ROOT / 'src/main/resources', refmap, target)
    with ZipFile(target) as jar:
        if jar.testzip() is not None:
            raise RuntimeError('Build generated an invalid ZIP archive.')
    print(target)

if __name__ == '__main__':
    main()
