# Chest Cavity · Minecraft 1.20.1 Forge 移植源码

对应移植版 **2.17.2.1-forge.7**。包含 Forge 适配、Butchery 5.2 / 5.3.1 的可选屠宰联动、鱼类和水生生物器官掉落、脾脏掉落，以及下界之星和海洋之心作为可各叠加 4 个的心脏替代品。

- `src/main/` 是移植源码与资源覆盖。
- `upstream/` 是原作者 David Troyer（Tigereye504）的参考源码快照。
- `tools/` 是构建时的映射、字节码移植和打包工具。
- `NOTICE.txt` 记录署名和许可来源。原版 JAR 与源码元数据标 CC0 1.0，CurseForge 页面标 Apache 2.0。两份许可文本都已随包附上。

## 构建

1. 安装 JDK 17 或更新版本，以及 Python 3.9 或更新版本。若 `java` 和 `javac` 未加入 PATH，设置 `JAVA_HOME`。
2. 使用 [Forge 1.20.1 官方安装器](https://files.minecraftforge.net/net/minecraftforge/forge/index_1.20.1.html) 把 **47.4.0** 安装为本地服务端。
3. 准备 [原版 Chest Cavity 2.17.2.1 Fabric JAR](https://www.curseforge.com/minecraft/mc-mods/chest-cavity/files/7539146) 和 `cloth-config-11.1.136-forge.jar`。
4. 在源码包根目录运行：

   ```sh
   python3 build.py --forge-server /path/to/forge-server \
     --fabric-jar /path/to/chestcavity-2.17.2.1.jar \
     --cloth-jar /path/to/cloth-config-11.1.136-forge.jar
   ```

首次构建会下载固定版本的映射和工具到 `build/inputs/`。构建从原版 JAR 重映射继承的类和资源，再编译、覆盖 Forge 适配源码。产物位于 `build/chestcavity-2.17.2.1-forge-1.20.1.jar`。运行移植版需同时安装 Forge 版 Cloth Config，Butchery 可选。
