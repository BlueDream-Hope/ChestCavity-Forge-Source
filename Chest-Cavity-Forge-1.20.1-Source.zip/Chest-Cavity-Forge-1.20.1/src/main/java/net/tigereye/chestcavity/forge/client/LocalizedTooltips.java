package net.tigereye.chestcavity.forge.client;

import java.util.List;
import net.minecraft.ChatFormatting;
import net.minecraft.client.Minecraft;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.item.enchantment.EnchantmentHelper;
import net.minecraft.world.level.Level;
import net.tigereye.chestcavity.ChestCavity;
import net.tigereye.chestcavity.interfaces.ChestCavityEntity;
import net.tigereye.chestcavity.registration.CCEnchantments;
import net.tigereye.chestcavity.util.ChestCavityUtil;

public final class LocalizedTooltips {
    public static void displayCompatibility(ItemStack stack, Level level, List<Component> tooltip, TooltipFlag flag) {
        var player = Minecraft.m_91087_().f_91074_;
        int compatibility = ChestCavityEntity.of(player).map(cavity ->
            ChestCavityUtil.getCompatibilityLevel(cavity.getChestCavityInstance(), stack)).orElse(-1);

        var tag = stack.m_41783_();
        var key = ChestCavity.COMPATIBILITY_TAG.toString();
        MutableComponent text;
        if (EnchantmentHelper.m_44843_(CCEnchantments.MALPRACTICE, stack) > 0) {
            text = Component.m_237115_("tooltip.chestcavity.unsafe");
        } else if (tag != null && tag.m_128441_(key) && EnchantmentHelper.m_44843_(CCEnchantments.O_NEGATIVE, stack) <= 0) {
            text = Component.m_237110_("tooltip.chestcavity.compatible_with", tag.m_128469_(key).m_128461_("name"));
        } else {
            text = Component.m_237115_("tooltip.chestcavity.safe");
        }
        tooltip.add(text.m_130940_(compatibility > 0 ? ChatFormatting.GREEN : compatibility == 0 ? ChatFormatting.RED : ChatFormatting.YELLOW));
    }
}
