package net.tigereye.chestcavity.registration;

import net.minecraft.world.level.storage.loot.entries.LootPoolEntryType;
import net.tigereye.chestcavity.loot.entry.ChestCavityLootEntry;

public final class CCLootPoolEntryTypes {
    public static final LootPoolEntryType CHEST_CAVITY_LOOT = new LootPoolEntryType(new ChestCavityLootEntry.Serializer());
}
