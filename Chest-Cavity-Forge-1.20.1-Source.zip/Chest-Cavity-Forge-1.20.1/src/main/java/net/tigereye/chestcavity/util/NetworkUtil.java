package net.tigereye.chestcavity.util;

import io.netty.buffer.Unpooled;
import java.util.HashMap;
import java.util.Map;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.tigereye.chestcavity.chestcavities.instance.ChestCavityInstance;
import net.tigereye.chestcavity.chestcavities.organs.OrganData;
import net.tigereye.chestcavity.chestcavities.organs.OrganManager;
import net.tigereye.chestcavity.registration.CCNetworkingPackets;

public final class NetworkUtil {
    public static boolean SendS2CChestCavityUpdatePacket(ChestCavityInstance cavity) {
        if (!(cavity.owner instanceof ServerPlayer)) return false;
        if (cavity.updatePacket != null) cavity.updatePacket.release();
        FriendlyByteBuf buffer = new FriendlyByteBuf(Unpooled.buffer());
        buffer.writeBoolean(cavity.opened);
        writeScores(buffer, cavity.getOrganScores());
        cavity.updatePacket = buffer;
        return SendS2CChestCavityUpdatePacket(cavity, buffer);
    }

    public static boolean SendS2CChestCavityUpdatePacket(ChestCavityInstance cavity, FriendlyByteBuf buffer) {
        if (!(cavity.owner instanceof ServerPlayer player) || player.f_8906_ == null || buffer == null) return false;
        CCNetworkingPackets.sendUpdate(player, copyBytes(buffer));
        cavity.updatePacket = null;
        buffer.release();
        return true;
    }

    public static void readUpdate(ChestCavityInstance cavity, FriendlyByteBuf buffer) {
        boolean opened = buffer.readBoolean();
        Map<ResourceLocation, Float> scores = readScores(buffer);
        cavity.opened = opened;
        cavity.setOrganScores(scores);
    }

    public static void SendC2SChestCavityHotkeyPacket(ResourceLocation ability) {
        CCNetworkingPackets.sendHotkey(ability);
    }

    public static byte[] writeOrganData() {
        FriendlyByteBuf buffer = new FriendlyByteBuf(Unpooled.buffer());
        try {
            buffer.writeInt(OrganManager.GeneratedOrganData.size());
            OrganManager.GeneratedOrganData.forEach((id, data) -> {
                buffer.m_130085_(id);
                buffer.writeBoolean(data.pseudoOrgan);
                writeScores(buffer, data.organScores);
            });
            return copyBytes(buffer);
        } finally {
            buffer.release();
        }
    }

    public static void readOrganData(FriendlyByteBuf buffer) {
        Map<ResourceLocation, OrganData> organs = new HashMap<>();
        int count = buffer.readInt();
        for (int i = 0; i < count; i++) {
            ResourceLocation id = buffer.m_130281_();
            OrganData data = new OrganData();
            data.pseudoOrgan = buffer.readBoolean();
            data.organScores.putAll(readScores(buffer));
            organs.put(id, data);
        }
        OrganManager.GeneratedOrganData = organs;
    }

    private static void writeScores(FriendlyByteBuf buffer, Map<ResourceLocation, Float> scores) {
        buffer.writeInt(scores.size());
        scores.forEach((id, score) -> {
            buffer.m_130085_(id);
            buffer.writeFloat(score);
        });
    }

    private static Map<ResourceLocation, Float> readScores(FriendlyByteBuf buffer) {
        int count = buffer.readInt();
        Map<ResourceLocation, Float> scores = new HashMap<>();
        for (int i = 0; i < count; i++) scores.put(buffer.m_130281_(), buffer.readFloat());
        return scores;
    }

    private static byte[] copyBytes(FriendlyByteBuf buffer) {
        byte[] copy = new byte[buffer.readableBytes()];
        buffer.getBytes(buffer.readerIndex(), copy);
        return copy;
    }
}
