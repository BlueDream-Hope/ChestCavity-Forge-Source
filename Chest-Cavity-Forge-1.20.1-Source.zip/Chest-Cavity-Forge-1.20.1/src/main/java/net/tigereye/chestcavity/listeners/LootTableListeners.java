package net.tigereye.chestcavity.listeners;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.level.storage.loot.LootPool;
import net.minecraft.world.level.storage.loot.entries.LootItem;
import net.minecraft.world.level.storage.loot.parameters.LootContextParams;
import net.minecraft.world.level.storage.loot.providers.number.BinomialDistributionGenerator;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.event.LootTableLoadEvent;
import net.tigereye.chestcavity.loot.condition.ChestCavityUnopenedLootCondition;
import net.tigereye.chestcavity.loot.entry.ChestCavityLootEntry;
import net.tigereye.chestcavity.registration.CCItems;

public final class LootTableListeners {
    private static final ResourceLocation DESERT_PYRAMID = new ResourceLocation("minecraft", "chests/desert_pyramid");

    public static void register() {
        MinecraftForge.EVENT_BUS.addListener(LootTableListeners::modify);
    }

    private static void modify(LootTableLoadEvent event) {
        if (event.getTable().m_79122_().m_81394_().contains(LootContextParams.f_81457_)) {
            event.getTable().addPool(LootPool.m_79043_().name("chestcavity_organ_drops")
                .m_79080_(ChestCavityUnopenedLootCondition::new)
                .m_79076_(ChestCavityLootEntry.builder()).m_79082_());
        }
        if (DESERT_PYRAMID.equals(event.getName())) {
            event.getTable().addPool(LootPool.m_79043_().name("chestcavity_rotten_rib")
                .m_165133_(BinomialDistributionGenerator.m_165659_(4, .25f))
                .m_79076_(LootItem.m_79579_(CCItems.ROTTEN_RIB)).m_79082_());
            event.getTable().addPool(LootPool.m_79043_().name("chestcavity_rotten_spine")
                .m_165133_(BinomialDistributionGenerator.m_165659_(1, .3f))
                .m_79076_(LootItem.m_79579_(CCItems.ROTTEN_SPINE)).m_79082_());
        }
    }
}
