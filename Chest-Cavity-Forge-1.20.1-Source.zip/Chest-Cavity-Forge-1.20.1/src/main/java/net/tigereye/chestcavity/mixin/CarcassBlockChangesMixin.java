package net.tigereye.chestcavity.mixin;

import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.chunk.LevelChunk;
import net.tigereye.chestcavity.compat.butchery.ButcheryCompat;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(LevelChunk.class)
public abstract class CarcassBlockChangesMixin {
    @Shadow public abstract Level m_62953_();

    @Inject(method = "m_6978_", at = @At("RETURN"), remap = false)
    private void chestcavity$preserveDonor(BlockPos pos, BlockState state, boolean moving,
            CallbackInfoReturnable<BlockState> ci) {
        if (ci.getReturnValue() != null && m_62953_() instanceof ServerLevel level) {
            ButcheryCompat.onBlockChanged(level, pos, ci.getReturnValue(), state);
        }
    }
}
