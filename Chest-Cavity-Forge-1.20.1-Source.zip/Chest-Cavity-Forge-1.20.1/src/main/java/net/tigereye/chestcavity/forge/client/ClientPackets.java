package net.tigereye.chestcavity.forge.client;

import io.netty.buffer.Unpooled;
import net.minecraft.client.Minecraft;
import net.minecraft.network.FriendlyByteBuf;
import net.tigereye.chestcavity.interfaces.ChestCavityEntity;
import net.tigereye.chestcavity.util.NetworkUtil;

public final class ClientPackets {
    public static void update(byte[] payload) {
        ChestCavityEntity.of(Minecraft.m_91087_().f_91074_).ifPresent(entity -> {
            FriendlyByteBuf buffer = new FriendlyByteBuf(Unpooled.wrappedBuffer(payload));
            try {
                NetworkUtil.readUpdate(entity.getChestCavityInstance(), buffer);
            } finally {
                buffer.release();
            }
        });
    }

    public static void organs(byte[] payload) {
        if (Minecraft.m_91087_().m_91090_()) return;
        FriendlyByteBuf buffer = new FriendlyByteBuf(Unpooled.wrappedBuffer(payload));
        try {
            NetworkUtil.readOrganData(buffer);
        } finally {
            buffer.release();
        }
    }
}
