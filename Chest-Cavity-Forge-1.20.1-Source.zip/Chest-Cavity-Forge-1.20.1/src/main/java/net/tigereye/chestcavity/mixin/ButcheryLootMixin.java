package net.tigereye.chestcavity.mixin;

import it.unimi.dsi.fastutil.objects.ObjectArrayList;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.storage.loot.LootParams;
import net.minecraft.world.level.storage.loot.LootTable;
import net.tigereye.chestcavity.compat.butchery.ButcheryCompat;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(LootTable.class)
public abstract class ButcheryLootMixin {
    @Shadow(remap = false) public abstract ResourceLocation getLootTableId();

    @Inject(method = "m_287195_", at = @At("RETURN"), remap = false)
    private void chestcavity$replaceButcheryOrgans(LootParams params,
            CallbackInfoReturnable<ObjectArrayList<ItemStack>> ci) {
        ButcheryCompat.replaceOrganLoot(getLootTableId(), ci.getReturnValue());
    }
}
