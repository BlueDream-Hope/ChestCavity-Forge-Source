package net.tigereye.chestcavity.compat.butchery;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.function.Supplier;
import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.Registries;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.tags.TagKey;
import net.minecraft.tags.ItemTags;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.boss.wither.WitherBoss;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.monster.ElderGuardian;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraftforge.common.ForgeConfigSpec.ConfigValue;
import net.minecraftforge.event.entity.EntityJoinLevelEvent;
import net.minecraftforge.event.entity.living.LivingDropsEvent;
import net.minecraftforge.fml.ModList;
import net.minecraftforge.registries.ForgeRegistries;
import net.tigereye.chestcavity.ChestCavity;
import net.tigereye.chestcavity.chestcavities.instance.ChestCavityInstanceFactory;
import net.tigereye.chestcavity.compat.butchery.CarcassDonorData.Donor;
import net.tigereye.chestcavity.interfaces.ChestCavityEntity;
import net.tigereye.chestcavity.registration.CCItems;

public final class ButcheryCompat {
    private static final String MOD_ID = "butchery";
    private static final String ROUTED_DROP = "chestcavity:butchery_drop";
    private static final float MUSCLE_DROP_CHANCE = 0.25f;
    private static final int MUSCLE_DROP_COUNT = 16;
    private static final Set<String> AQUATIC_CARCASSES = Set.of(
        "cod", "salmon", "pufferfish", "squid", "glow_squid", "guardian", "elder_guardian");
    private static final Map<String, String> HUMAN_MEAT = Map.of(
        "villager", "raw_villager_steak",
        "pillager", "raw_pillager_meat",
        "vindicator", "raw_vindicator_meat",
        "evoker", "raw_evoker_meat",
        "witch", "raw_witch_meat");
    private static final ResourceLocation IRON_GOLEM = new ResourceLocation("minecraft", "iron_golem");
    private static final ResourceLocation ELDER_GUARDIAN = new ResourceLocation("minecraft", "elder_guardian");
    private static final ResourceLocation WITHER = new ResourceLocation("minecraft", "wither");
    private static final TagKey<Item> FORGE_CLEAVER = ItemTags.create(new ResourceLocation("forge", "cleaver"));
    private static final TagKey<Item> COMMON_CLEAVER = ItemTags.create(new ResourceLocation("c", "cleaver"));
    private static final ThreadLocal<Interaction> CARCASS_INTERACTION = new ThreadLocal<>();
    private static final ThreadLocal<ArrayDeque<LivingEntity>> DYING = new ThreadLocal<>();
    private static final ThreadLocal<Donor> PLACING_DONOR = new ThreadLocal<>();
    private static final Map<ResourceLocation, Species> SPECIES = new LinkedHashMap<>();
    private static final Map<String, Species> CARCASSES = new LinkedHashMap<>();
    private static final Map<String, ConfigValue<?>> OPTIONS = new LinkedHashMap<>();
    private static boolean loaded;

    public record Species(ResourceLocation id, String[] options, String[] tags) {}

    private record Tissues(Map<String, ItemStack> organs, List<ItemStack> muscles, List<ItemStack> aquaticOrgans) {}

    public static final class Interaction {
        private final ServerLevel level;
        private final BlockPos pos;
        private final Species species;
        private final Donor donor;
        private final Tissues tissues;
        private boolean cutLoot;
        private boolean moved;
        private String golemCut;

        private Interaction(ServerLevel level, BlockPos pos, Species species, Donor donor, Tissues tissues) {
            this.level = level;
            this.pos = pos;
            this.species = species;
            this.donor = donor;
            this.tissues = tissues;
        }
    }

    public static void register() {
        if (!ModList.get().isLoaded(MOD_ID)) return;
        try {
            Class<?> config = Class.forName("net.mcreator.butchery.configuration.ButcheryconfigConfiguration");
            for (var field : config.getFields()) {
                if (field.getType() == ConfigValue.class) {
                    OPTIONS.put(field.getName(), (ConfigValue<?>) field.get(null));
                }
            }

            try (var input = ButcheryCompat.class.getResourceAsStream("/chestcavity-butchery-5.2.tsv");
                 var reader = new BufferedReader(new InputStreamReader(input, StandardCharsets.UTF_8))) {
                String line;
                while ((line = reader.readLine()) != null) {
                    String[] parts = line.split("\t", -1);
                    var species = new Species(new ResourceLocation("minecraft", parts[0]), parts[1].split(","), parts[2].split(","));
                    SPECIES.put(species.id(), species);
                    for (String block : parts[3].split(",")) CARCASSES.put(block, species);
                }
            }
            loaded = true;
            ChestCavity.LOGGER.info("Loaded Chest Cavity integration for {} Butchery species.", SPECIES.size());
        } catch (ReflectiveOperationException | IOException e) {
            ChestCavity.LOGGER.warn("Could not load Chest Cavity's Butchery integration.", e);
        }
    }

    private static boolean enabled(String name) {
        var value = OPTIONS.get(name);
        return value != null && Boolean.TRUE.equals(value.get());
    }

    public static boolean handles(LivingEntity target) {
        if (!loaded || target instanceof Player || target.m_6162_()) return false;
        Species species = SPECIES.get(ForgeRegistries.ENTITY_TYPES.getKey(target.m_6095_()));
        if (species == null) {
            for (Species candidate : SPECIES.values()) {
                if (matchesTags(target.m_6095_(), candidate.tags())) {
                    species = candidate;
                    break;
                }
            }
        }
        if (species == null) return false;
        for (String option : species.options()) {
            if (enabled(option)) return true;
        }
        return false;
    }

    private static boolean matchesTags(EntityType<?> type, String[] names) {
        for (String name : names) {
            if (name.isEmpty()) continue;
            if (type.m_204039_(TagKey.m_203882_(Registries.f_256939_, new ResourceLocation("forge", name)))
                || type.m_204039_(TagKey.m_203882_(Registries.f_256939_, new ResourceLocation("c", name)))) return true;
        }
        return false;
    }

    public static void beforeDeath(LivingEntity entity) {
        if (!loaded || entity.m_9236_().m_5776_()) return;
        var dying = DYING.get();
        if (dying == null) {
            dying = new ArrayDeque<>();
            DYING.set(dying);
        }
        entity.getPersistentData().m_128473_(ROUTED_DROP);
        dying.push(entity);
    }

    public static void afterDeath(LivingEntity entity) {
        if (!loaded || entity.m_9236_().m_5776_()) return;
        var dying = DYING.get();
        if (dying == null) return;
        dying.pop();
        if (dying.isEmpty()) DYING.remove();
    }

    public static Runnable preserveElderGuardianDonor(Runnable action) {
        var dying = DYING.get();
        if (dying == null || !(dying.peek() instanceof ElderGuardian elder)) return action;
        Donor donor = donorOf(elder, ELDER_GUARDIAN);
        elder.getPersistentData().m_128379_(ROUTED_DROP, true);
        return () -> {
            Donor previous = PLACING_DONOR.get();
            PLACING_DONOR.set(donor);
            try {
                action.run();
            } finally {
                if (previous == null) PLACING_DONOR.remove();
                else PLACING_DONOR.set(previous);
            }
        };
    }

    public static void bindWitherStar(LivingDropsEvent event) {
        if (!(event.getEntity() instanceof WitherBoss wither)) return;
        Donor donor = donorOf(wither, WITHER);
        List<ItemEntity> stars = event.getDrops().stream()
            .filter(drop -> drop.m_32055_().m_41720_() == Items.f_42686_).toList();
        if (stars.isEmpty()) return;
        ItemEntity star = stars.get(stars.size() - 1);
        event.getDrops().removeIf(drop -> drop != star && drop.m_32055_().m_41720_() == Items.f_42686_);
        star.m_32055_().m_41764_(1);
        donor.bindOrgan(star.m_32055_());
    }

    public static void detectCarcass(EntityJoinLevelEvent event) {
        if (!loaded || !(event.getLevel() instanceof ServerLevel level)
            || !(event.getEntity() instanceof ItemEntity drop)) return;
        ItemStack stack = drop.m_32055_();
        Species species = carcassSpecies(stack);
        if (species == null) return;

        var dying = DYING.get();
        if (dying != null && attachDeathDonor(dying.peek(), drop, species)) return;

        Interaction scope = CARCASS_INTERACTION.get();
        if (scope != null && level == scope.level && scope.donor != null && species == scope.species
            && scope.pos.m_123314_(drop.m_20183_(), 2.0)) {
            scope.moved = true;
            if (CarcassDonorData.fromCarcass(stack) == null) scope.donor.bindCarcass(stack);
        }
    }

    private static boolean attachDeathDonor(LivingEntity victim, ItemEntity drop, Species species) {
        if (victim.m_20280_(drop) > 4.0) return false;
        var id = ForgeRegistries.ENTITY_TYPES.getKey(victim.m_6095_());
        if (id == null || !(species.id().equals(id) || matchesTags(victim.m_6095_(), species.tags())
            || "trader_llama".equals(id.m_135815_()) && "llama".equals(species.id().m_135815_()))) return false;

        donorOf(victim, id).bindCarcass(drop.m_32055_());
        victim.getPersistentData().m_128379_(ROUTED_DROP, true);
        return true;
    }

    private static Donor donorOf(LivingEntity victim, ResourceLocation id) {
        UUID owner = ChestCavityEntity.of(victim).map(entity -> entity.getChestCavityInstance().compatibility_id)
            .orElse(victim.m_20148_());
        return new Donor(owner, victim.m_5446_().getString(), id);
    }

    public static boolean movedToButchery(LivingEntity entity) {
        return loaded && entity.getPersistentData().m_128471_(ROUTED_DROP);
    }

    public static <T> T withCarcass(ServerLevel level, BlockPos pos, ItemStack held, Supplier<T> action) {
        Interaction previous = beginInteraction(level, pos, held, true);
        try {
            T result = action.get();
            Interaction scope = CARCASS_INTERACTION.get();
            if (scope != null) finishCarcass(scope, held);
            return result;
        } finally {
            restoreInteraction(previous);
        }
    }

    public static Interaction beginInteraction(ServerLevel level, BlockPos pos, ItemStack held, boolean cutting) {
        Interaction previous = CARCASS_INTERACTION.get();
        if (!loaded) return previous;

        Species species = carcassSpecies(level.m_8055_(pos));
        Donor donor = null;
        Tissues tissues = null;
        if (species != null) {
            var data = CarcassDonorData.of(level);
            donor = data.get(pos);
            if (donor == null) {
                donor = unknownDonor(species);
                data.put(pos, donor);
            }
            if (cutting) tissues = profileTissues(species, donor);
        } else {
            species = carcassSpecies(held);
            if (species != null) {
                donor = CarcassDonorData.fromCarcass(held);
                if (donor == null) donor = unknownDonor(species);
            }
        }

        if (species != null) CARCASS_INTERACTION.set(new Interaction(level, pos, species, donor, tissues));
        else CARCASS_INTERACTION.remove();
        return previous;
    }

    public static void restoreInteraction(Interaction previous) {
        if (previous == null) CARCASS_INTERACTION.remove();
        else CARCASS_INTERACTION.set(previous);
    }

    public static void onCarcassPlaced(ServerLevel level, BlockPos pos, ItemStack stack, BlockState state) {
        if (!loaded) return;
        Species species = carcassSpecies(state);
        if (species == null || species != carcassSpecies(stack)) return;
        Donor donor = CarcassDonorData.fromCarcass(stack);
        CarcassDonorData.of(level).put(pos, donor == null ? unknownDonor(species) : donor);
    }

    public static void onBlockChanged(ServerLevel level, BlockPos pos, BlockState oldState, BlockState newState) {
        if (!loaded) return;
        Species oldSpecies = carcassSpecies(oldState);
        Species newSpecies = carcassSpecies(newState);
        if (oldSpecies == newSpecies) return;
        if (oldSpecies != null) CarcassDonorData.of(level).remove(pos);
        Donor placingDonor = PLACING_DONOR.get();
        if (newSpecies != null && placingDonor != null && newSpecies.id().equals(placingDonor.entityType())) {
            CarcassDonorData.of(level).put(pos, placingDonor);
            return;
        }

        Interaction scope = CARCASS_INTERACTION.get();
        if (newSpecies != null && scope != null && level == scope.level && newSpecies == scope.species
            && scope.pos.m_123314_(pos, 2.0)) {
            CarcassDonorData.of(level).put(pos, scope.donor);
        }
    }

    private static Donor unknownDonor(Species species) {
        EntityType<?> type = ForgeRegistries.ENTITY_TYPES.getValue(species.id());
        String name = type == null ? species.id().m_135815_() : type.m_20676_().getString();
        return new Donor(UUID.randomUUID(), name, species.id());
    }

    private static Species carcassSpecies(ItemStack stack) {
        return stack != null && stack.m_41720_() instanceof BlockItem item
            ? carcassSpecies(item.m_40614_().m_49966_()) : null;
    }

    private static Species carcassSpecies(BlockState state) {
        var blockId = ForgeRegistries.BLOCKS.getKey(state.m_60734_());
        if (blockId == null || !blockId.m_135827_().equals(MOD_ID)) return null;
        return CARCASSES.get(blockId.m_135815_());
    }

    private static Tissues profileTissues(Species species, Donor donor) {
        var profile = ChestCavityInstanceFactory.getAssignedType(donor.entityType());
        if (profile == null) profile = ChestCavityInstanceFactory.getAssignedType(species.id());
        if (profile == null || profile.getDefaultChestCavity() == null) return null;

        var inventory = profile.getDefaultChestCavity();
        Map<String, ItemStack> organs = new LinkedHashMap<>();
        List<ItemStack> muscles = new ArrayList<>();
        List<ItemStack> aquaticOrgans = new ArrayList<>();
        boolean aquatic = AQUATIC_CARCASSES.contains(species.id().m_135815_());
        for (int slot = 0; slot < inventory.m_6643_(); slot++) {
            ItemStack stack = inventory.m_8020_(slot);
            if (stack.m_41619_()) continue;
            var id = ForgeRegistries.ITEMS.getKey(stack.m_41720_());
            if (id == null) continue;
            if (!id.m_135827_().equals(ChestCavity.MODID)) {
                if (aquatic && stack.m_41720_() == Items.f_42716_) aquaticOrgans.add(stack);
                continue;
            }
            String role = organRole(id.m_135815_());
            if ("muscle".equals(role)) {
                muscles.add(stack);
            } else {
                if (role != null) organs.putIfAbsent(role, stack);
                if (aquatic) aquaticOrgans.add(stack);
            }
        }
        return new Tissues(organs, muscles, aquaticOrgans);
    }

    public static void replaceOrganLoot(ResourceLocation table, List<ItemStack> drops) {
        Interaction scope = CARCASS_INTERACTION.get();
        if (scope == null || scope.tissues == null || table == null || !table.m_135827_().equals(MOD_ID)) return;

        scope.cutLoot |= !drops.isEmpty();
        if (IRON_GOLEM.equals(scope.species.id())) {
            switch (table.m_135815_()) {
                case "blocks/iron_golem_cut_1_drop", "blocks/repaired_iron_golem_cut_1_drop" -> scope.golemCut = "arms";
                case "blocks/iron_golem_cut_2_drop", "blocks/repaired_iron_golem_cut_2_drop" -> scope.golemCut = "body";
                default -> {}
            }
        }
        var entries = drops.listIterator();
        String humanMeat = HUMAN_MEAT.get(scope.species.id().m_135815_());
        while (entries.hasNext()) {
            ItemStack drop = entries.next();
            if (drop.m_41619_()) continue;
            var id = ForgeRegistries.ITEMS.getKey(drop.m_41720_());
            if (id == null || !id.m_135827_().equals(MOD_ID) || id.m_135815_().startsWith("cooked_")) continue;
            String role = organRole(id.m_135815_());
            boolean meat = id.m_135815_().equals(humanMeat);
            ItemStack replacement = meat ? new ItemStack(CCItems.HUMAN_MUSCLE) : scope.tissues.organs().get(role);
            // Aquatic anatomy and spleens are emitted once, when the final cut consumes the carcass.
            boolean aquatic = !scope.tissues.aquaticOrgans().isEmpty();
            if (aquatic && (replacement != null || "lungs".equals(role))
                || replacement != null && "spleen".equals(role)) {
                entries.remove();
                continue;
            }
            if (replacement == null) continue;

            int remaining = meat ? drop.m_41613_() * MUSCLE_DROP_COUNT
                : "lungs".equals(role) ? 2 : drop.m_41613_();
            int limit = meat ? Math.min(MUSCLE_DROP_COUNT, replacement.m_41741_()) : replacement.m_41741_();
            int count = Math.min(remaining, limit);
            ItemStack organ = replacement.m_255036_(count);
            scope.donor.bindOrgan(organ);
            entries.set(organ);
            remaining -= count;
            while (remaining > 0) {
                count = Math.min(remaining, limit);
                entries.add(organ.m_255036_(count));
                remaining -= count;
            }
        }
    }

    private static void finishCarcass(Interaction scope, ItemStack held) {
        if (scope.tissues == null || scope.moved || carcassSpecies(scope.level.m_8055_(scope.pos)) != null) return;
        if (IRON_GOLEM.equals(scope.species.id())) {
            finishGolemPart(scope);
            return;
        }
        if (!scope.cutLoot && !held.m_204117_(FORGE_CLEAVER) && !held.m_204117_(COMMON_CLEAVER)) return;

        if (scope.tissues.aquaticOrgans().isEmpty()) {
            dropTissue(scope, scope.tissues.organs().get("rib"), 1);
            dropTissue(scope, scope.tissues.organs().get("spine"), 1);
            dropTissue(scope, scope.tissues.organs().get("spleen"), 1);
        } else {
            for (ItemStack organ : scope.tissues.aquaticOrgans()) {
                dropTissue(scope, organ, 1);
            }
        }
        if (HUMAN_MEAT.containsKey(scope.species.id().m_135815_())) return;
        List<ItemStack> muscles = scope.tissues.muscles();
        var random = scope.level.m_213780_();
        if (!muscles.isEmpty() && random.m_188501_() < MUSCLE_DROP_CHANCE) {
            dropTissue(scope, muscles.get(random.m_188503_(muscles.size())), MUSCLE_DROP_COUNT);
        }
    }

    private static void finishGolemPart(Interaction scope) {
        if ("arms".equals(scope.golemCut)) {
            dropTissue(scope, new ItemStack(CCItems.PISTON_MUSCLE), MUSCLE_DROP_COUNT);
        } else if ("body".equals(scope.golemCut)) {
            dropTissue(scope, new ItemStack(CCItems.GOLEM_CORE), 1);
            dropTissue(scope, new ItemStack(CCItems.GOLEM_PLATING), 1);
            dropTissue(scope, new ItemStack(ForgeRegistries.ITEMS.getValue(ChestCavity.id("golem_spine"))), 1);
            dropTissue(scope, new ItemStack(CCItems.INNER_FURNACE), 1);
        }
    }

    private static void dropTissue(Interaction scope, ItemStack template, int count) {
        if (template == null) return;
        for (int remaining = count; remaining > 0;) {
            int size = Math.min(remaining, template.m_41741_());
            ItemStack stack = template.m_255036_(size);
            scope.donor.bindOrgan(stack);
            var drop = new ItemEntity(scope.level, scope.pos.m_123341_() + .5, scope.pos.m_123342_() + .5,
                scope.pos.m_123343_() + .5, stack);
            drop.m_32010_(10);
            scope.level.m_7967_(drop);
            remaining -= size;
        }
    }

    private static String organRole(String path) {
        String part = path.substring(path.lastIndexOf('_') + 1);
        return switch (part) {
            case "heart", "kidney", "liver", "stomach", "rib", "spine", "spleen", "muscle" -> part;
            case "lung", "lungs" -> "lungs";
            case "intestine", "intestines" -> "intestines";
            default -> null;
        };
    }
}
