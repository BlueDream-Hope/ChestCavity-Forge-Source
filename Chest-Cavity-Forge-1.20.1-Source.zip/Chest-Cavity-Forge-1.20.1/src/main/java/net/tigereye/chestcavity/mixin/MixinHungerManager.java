package net.tigereye.chestcavity.mixin;

import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.food.FoodData;
import net.minecraft.world.food.FoodProperties;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.tigereye.chestcavity.chestcavities.instance.ChestCavityInstance;
import net.tigereye.chestcavity.interfaces.ChestCavityEntity;
import net.tigereye.chestcavity.listeners.EffectiveFoodScores;
import net.tigereye.chestcavity.listeners.OrganFoodCallback;
import net.tigereye.chestcavity.registration.CCOrganScores;
import net.tigereye.chestcavity.util.ChestCavityUtil;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyVariable;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(FoodData.class)
public abstract class MixinHungerManager {
    @Shadow private int f_38699_;
    @Shadow private float f_38698_;

    @Unique private ChestCavityEntity chestcavity$player;

    @Inject(method = "m_38710_", at = @At("HEAD"), remap = false)
    private void chestcavity$applyMetabolism(Player player, CallbackInfo info) {
        chestcavity$player = ChestCavityEntity.of(player).orElse(null);
        if (chestcavity$player != null) {
            f_38699_ = ChestCavityUtil.applySpleenMetabolism(chestcavity$player.getChestCavityInstance(), f_38699_);
        }
    }

    @Redirect(method = "eat(Lnet/minecraft/world/item/Item;Lnet/minecraft/world/item/ItemStack;Lnet/minecraft/world/entity/LivingEntity;)V",
        at = @At(value = "INVOKE", target = "Lnet/minecraft/world/food/FoodData;m_38707_(IF)V"), remap = false)
    private void chestcavity$applyDiet(FoodData foodData, int hunger, float saturation, Item item, ItemStack stack, LivingEntity eater) {
        ChestCavityEntity player = ChestCavityEntity.of(eater).orElse(chestcavity$player);
        FoodProperties food = stack.getFoodProperties(eater);
        if (player != null && food != null) {
            ChestCavityInstance cavity = player.getChestCavityInstance();
            EffectiveFoodScores scores = new EffectiveFoodScores(cavity.getOrganScore(CCOrganScores.DIGESTION),
                cavity.getOrganScore(CCOrganScores.NUTRITION));
            scores = OrganFoodCallback.EVENT.invoker().onEatFood(item, food, player, scores);
            float saturationGain = ChestCavityUtil.applyNutrition(cavity, scores.nutrition, saturation) * hunger * 2;
            hunger = ChestCavityUtil.applyDigestion(cavity, scores.digestion, hunger);
            saturation = hunger == 0 ? 0 : saturationGain / (hunger * 2);
        }
        foodData.m_38707_(hunger, saturation);
    }

    @ModifyVariable(method = "m_38703_", at = @At("HEAD"), argsOnly = true, ordinal = 0, remap = false)
    private float chestcavity$applyEndurance(float exhaustion) {
        if (chestcavity$player == null) return exhaustion;
        if (Float.isNaN(f_38698_)) f_38698_ = 0;

        ChestCavityInstance cavity = chestcavity$player.getChestCavityInstance();
        float delta = cavity.getOrganScore(CCOrganScores.ENDURANCE)
            - cavity.getChestCavityType().getDefaultOrganScore(CCOrganScores.ENDURANCE);
        return delta > 0 ? exhaustion / (1 + delta / 2) : exhaustion * (1 - delta / 2);
    }
}
