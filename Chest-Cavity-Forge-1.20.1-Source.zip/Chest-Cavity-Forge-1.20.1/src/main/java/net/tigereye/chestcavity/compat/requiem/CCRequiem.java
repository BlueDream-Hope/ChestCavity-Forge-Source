package net.tigereye.chestcavity.compat.requiem;

import net.minecraft.resources.ResourceLocation;

public final class CCRequiem {
    public static final ResourceLocation PLAYER_SHELL_ID = new ResourceLocation("requiem", "player_shell");
}
