package net.tigereye.chestcavity;

import me.shedaniel.autoconfig.AutoConfig;
import me.shedaniel.autoconfig.serializer.GsonConfigSerializer;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.inventory.MenuType;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.event.AddReloadListenerEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.event.entity.player.PlayerInteractEvent;
import net.minecraftforge.eventbus.api.EventPriority;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.LivingEntity;
import net.tigereye.chestcavity.compat.butchery.ButcheryCompat;
import net.tigereye.chestcavity.items.ChestOpener;
import net.tigereye.chestcavity.interfaces.ChestCavityEntity;
import net.tigereye.chestcavity.util.NetworkUtil;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import net.tigereye.chestcavity.chestcavities.organs.OrganManager;
import net.tigereye.chestcavity.chestcavities.types.json.GeneratedChestCavityAssignmentManager;
import net.tigereye.chestcavity.chestcavities.types.json.GeneratedChestCavityTypeManager;
import net.tigereye.chestcavity.config.CCConfig;
import net.tigereye.chestcavity.forge.ForgeRegistration;
import net.tigereye.chestcavity.forge.client.ClientEvents;
import net.tigereye.chestcavity.registration.*;
import net.tigereye.chestcavity.ui.ChestCavityScreenHandler;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

@Mod(ChestCavity.MODID)
public final class ChestCavity {
    public static final String MODID = "chestcavity";
    public static final Logger LOGGER = LogManager.getLogger();
    public static final ResourceLocation COMPATIBILITY_TAG = id("organ_compatibility");
    public static final ResourceLocation CHEST_CAVITY_SCREEN_ID = id("chest_cavity_screen");
    public static final boolean DEBUG_MODE = false;
    public static CCConfig config;
    public static MenuType<ChestCavityScreenHandler> CHEST_CAVITY_SCREEN_HANDLER;

    public ChestCavity() {
        AutoConfig.register(CCConfig.class, GsonConfigSerializer::new);
        config = AutoConfig.getConfigHolder(CCConfig.class).getConfig();

        IEventBus modBus = FMLJavaModLoadingContext.get().getModEventBus();
        modBus.addListener(ForgeRegistration::register);
        modBus.addListener(ChestCavity::setupCompatibility);
        modBus.addListener(ForgeRegistration::fillVanillaTabs);
        DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> ClientEvents.install(modBus));

        IEventBus gameBus = MinecraftForge.EVENT_BUS;
        gameBus.addListener(ChestCavity::addReloadListeners);
        gameBus.addListener(CCCommands::register);
        gameBus.addListener(CCNetworkingPackets::syncOrgans);
        gameBus.addListener(ChestCavity::syncDimensionChange);
        gameBus.addListener(EventPriority.LOWEST, ButcheryCompat::detectCarcass);
        gameBus.addListener(EventPriority.LOWEST, ButcheryCompat::bindWitherStar);
        gameBus.addListener(ChestCavity::restrictSpecificInteraction);
        CCNetworkingPackets.register();
        CCListeners.register();
        CCOrganScores.register();
        CCTagOrgans.init();
    }

    public static ResourceLocation id(String path) {
        return new ResourceLocation(MODID, path);
    }

    private static void setupCompatibility(FMLCommonSetupEvent event) {
        event.enqueueWork(ButcheryCompat::register);
    }

    private static void restrictSpecificInteraction(PlayerInteractEvent.EntityInteractSpecific event) {
        var player = event.getEntity();
        if (player.m_9236_().m_5776_() || event.getItemStack().m_41720_() != CCItems.CHEST_OPENER
            || !(event.getTarget() instanceof LivingEntity target)) return;
        if (ChestOpener.isRestricted(player, target)) {
            event.setCancellationResult(InteractionResult.SUCCESS);
            event.setCanceled(true);
        }
    }

    private static void syncDimensionChange(PlayerEvent.PlayerChangedDimensionEvent event) {
        ChestCavityEntity.of(event.getEntity()).ifPresent(entity ->
            NetworkUtil.SendS2CChestCavityUpdatePacket(entity.getChestCavityInstance()));
    }

    private static void addReloadListeners(AddReloadListenerEvent event) {
        event.addListener(new OrganManager());
        event.addListener(new GeneratedChestCavityTypeManager());
        event.addListener(new GeneratedChestCavityAssignmentManager());
    }
}
