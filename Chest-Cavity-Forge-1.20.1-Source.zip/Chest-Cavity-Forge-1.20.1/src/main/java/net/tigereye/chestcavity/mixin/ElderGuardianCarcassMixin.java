package net.tigereye.chestcavity.mixin;

import net.tigereye.chestcavity.compat.butchery.ButcheryCompat;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Pseudo;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyArg;

@Pseudo
@Mixin(targets = "net.mcreator.butchery.procedures.ElderguardiandropProcedure", remap = false)
public abstract class ElderGuardianCarcassMixin {
    @ModifyArg(method = "execute(Lnet/minecraftforge/eventbus/api/Event;Lnet/minecraft/world/level/LevelAccessor;"
        + "Lnet/minecraft/world/entity/Entity;Lnet/minecraft/world/entity/Entity;)V", at = @At(value = "INVOKE", target =
        "Lnet/mcreator/butchery/ButcheryMod;queueServerWork(ILjava/lang/Runnable;)V"), index = 1, require = 0)
    private static Runnable chestcavity$keepDelayedCarcassDonor(Runnable action) {
        return ButcheryCompat.preserveElderGuardianDonor(action);
    }
}
