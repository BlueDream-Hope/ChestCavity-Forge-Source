package net.tigereye.chestcavity.mixin;

import java.util.Map;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.ItemStack;
import net.tigereye.chestcavity.items.HeartImplants;
import net.tigereye.chestcavity.registration.CCOrganScores;
import net.tigereye.chestcavity.util.ChestCavityUtil;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

@Mixin(value = ChestCavityUtil.class, remap = false)
public abstract class HeartScoreMixin {
    @Redirect(method = {"lambda$determineDefaultOrganScores$0", "lambda$evaluateChestCavity$1"},
        at = @At(value = "INVOKE", target = "Ljava/lang/Math;min(FF)F"),
        require = 2)
    private static float chestcavity$countStackedHearts(float stackRatio, float maxRatio,
            ItemStack stack, Map<ResourceLocation, Float> scores, ResourceLocation score, Float value) {
        if (HeartImplants.isStackableHeart(stack)) {
            return CCOrganScores.HEALTH.getID().equals(score)
                ? Math.min(stack.m_41613_(), HeartImplants.MAX_PER_SLOT) : 1.0f;
        }
        return Math.min(stackRatio, maxRatio);
    }
}
