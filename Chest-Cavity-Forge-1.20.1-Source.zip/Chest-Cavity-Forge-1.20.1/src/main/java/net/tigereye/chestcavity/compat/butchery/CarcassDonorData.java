package net.tigereye.chestcavity.compat.butchery;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.saveddata.SavedData;
import net.tigereye.chestcavity.ChestCavity;

public final class CarcassDonorData extends SavedData {
    private static final String ITEM_DONOR = "chestcavity:carcass_donor";
    private final Map<Long, Donor> donors = new HashMap<>();

    public record Donor(UUID id, String name, ResourceLocation entityType) {
        private CompoundTag compatibility() {
            var tag = new CompoundTag();
            tag.m_128362_("owner", id);
            tag.m_128359_("name", name);
            return tag;
        }

        private CompoundTag save() {
            var tag = compatibility();
            tag.m_128359_("entity_type", entityType.toString());
            return tag;
        }

        private static Donor load(CompoundTag tag) {
            var type = ResourceLocation.m_135820_(tag.m_128461_("entity_type"));
            return tag.m_128403_("owner") && type != null
                ? new Donor(tag.m_128342_("owner"), tag.m_128461_("name"), type) : null;
        }

        void bindOrgan(ItemStack stack) {
            stack.m_41700_(ChestCavity.COMPATIBILITY_TAG.toString(), compatibility());
        }

        void bindCarcass(ItemStack stack) {
            stack.m_41700_(ITEM_DONOR, save());
        }
    }

    static Donor fromCarcass(ItemStack stack) {
        CompoundTag root = stack.m_41783_();
        return root == null || !root.m_128425_(ITEM_DONOR, 10) ? null : Donor.load(root.m_128469_(ITEM_DONOR));
    }

    static CarcassDonorData of(ServerLevel level) {
        return level.m_8895_().m_164861_(CarcassDonorData::load, CarcassDonorData::new, "chestcavity_carcass_donors");
    }

    private static CarcassDonorData load(CompoundTag tag) {
        var data = new CarcassDonorData();
        ListTag entries = tag.m_128437_("donors", 10);
        for (int i = 0; i < entries.size(); i++) {
            CompoundTag entry = entries.m_128728_(i);
            Donor donor = Donor.load(entry);
            if (donor != null) data.donors.put(entry.m_128454_("pos"), donor);
        }
        return data;
    }

    Donor get(BlockPos pos) {
        return donors.get(pos.m_121878_());
    }

    void put(BlockPos pos, Donor donor) {
        if (!donor.equals(donors.put(pos.m_121878_(), donor))) m_77762_();
    }

    void remove(BlockPos pos) {
        if (donors.remove(pos.m_121878_()) != null) m_77762_();
    }

    @Override
    public CompoundTag m_7176_(CompoundTag tag) {
        ListTag entries = new ListTag();
        donors.forEach((pos, donor) -> {
            CompoundTag entry = donor.save();
            entry.m_128356_("pos", pos);
            entries.add(entry);
        });
        tag.m_128365_("donors", entries);
        return tag;
    }
}
