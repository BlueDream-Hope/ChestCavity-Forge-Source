package net.tigereye.chestcavity.forge;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.List;
import java.util.function.Function;

public final class CallbackEvent<T> {
    private final List<T> listeners = new ArrayList<>();
    private final Class<T> type;
    private final Function<T[], T> factory;
    private volatile T invoker;

    private CallbackEvent(Class<T> type, Function<T[], T> factory) {
        this.type = type;
        this.factory = factory;
        rebuild();
    }

    public static <T> CallbackEvent<T> createArrayBacked(Class<T> type, Function<T[], T> factory) {
        return new CallbackEvent<>(type, factory);
    }

    public synchronized void register(T listener) {
        listeners.add(listener);
        rebuild();
    }

    public T invoker() {
        return invoker;
    }

    @SuppressWarnings("unchecked")
    private void rebuild() {
        invoker = factory.apply(listeners.toArray((T[]) Array.newInstance(type, listeners.size())));
    }
}
