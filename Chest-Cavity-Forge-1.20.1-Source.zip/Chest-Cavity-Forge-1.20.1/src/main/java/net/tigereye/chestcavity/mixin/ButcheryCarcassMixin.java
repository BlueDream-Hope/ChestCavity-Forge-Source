package net.tigereye.chestcavity.mixin;

import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayerGameMode;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraftforge.common.ForgeHooks;
import net.minecraftforge.event.entity.player.PlayerInteractEvent;
import net.tigereye.chestcavity.compat.butchery.ButcheryCompat;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(ServerPlayerGameMode.class)
public abstract class ButcheryCarcassMixin {
    @Shadow protected ServerLevel f_9244_;
    @Unique private ButcheryCompat.Interaction chestcavity$previousBreak;

    @Redirect(method = "m_7179_", at = @At(value = "INVOKE", target =
        "Lnet/minecraftforge/common/ForgeHooks;onRightClickBlock(Lnet/minecraft/world/entity/player/Player;"
        + "Lnet/minecraft/world/InteractionHand;Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/phys/BlockHitResult;)"
        + "Lnet/minecraftforge/event/entity/player/PlayerInteractEvent$RightClickBlock;"), remap = false)
    private PlayerInteractEvent.RightClickBlock chestcavity$cutCarcass(
            Player player, InteractionHand hand, BlockPos pos, BlockHitResult hit) {
        return ButcheryCompat.withCarcass(f_9244_, pos, player.m_21120_(hand),
            () -> ForgeHooks.onRightClickBlock(player, hand, pos, hit));
    }

    @Redirect(method = "m_7179_", at = @At(value = "INVOKE", target =
        "Lnet/minecraft/world/level/block/state/BlockState;m_60664_(Lnet/minecraft/world/level/Level;"
        + "Lnet/minecraft/world/entity/player/Player;Lnet/minecraft/world/InteractionHand;"
        + "Lnet/minecraft/world/phys/BlockHitResult;)Lnet/minecraft/world/InteractionResult;"), remap = false)
    private InteractionResult chestcavity$useCarcassBlock(
            BlockState state, Level level, Player player, InteractionHand hand, BlockHitResult hit) {
        return ButcheryCompat.withCarcass(f_9244_, hit.m_82425_(), player.m_21120_(hand),
            () -> state.m_60664_(level, player, hand, hit));
    }

    @Inject(method = "m_9280_", at = @At("HEAD"), remap = false)
    private void chestcavity$breakCarcass(BlockPos pos, CallbackInfoReturnable<Boolean> ci) {
        chestcavity$previousBreak = ButcheryCompat.beginInteraction(f_9244_, pos, null, false);
    }

    @Inject(method = "m_9280_", at = @At("RETURN"), remap = false)
    private void chestcavity$afterBreak(BlockPos pos, CallbackInfoReturnable<Boolean> ci) {
        ButcheryCompat.restoreInteraction(chestcavity$previousBreak);
        chestcavity$previousBreak = null;
    }
}
