package net.tigereye.chestcavity.items;

import java.util.List;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.item.Item.Properties;
import net.minecraft.world.level.Level;

public class CreeperAppendix extends Item {
   public CreeperAppendix() {
      super(new Properties().m_41487_(1));
   }

   public void m_7373_(ItemStack itemStack, Level world, List<Component> tooltip, TooltipFlag tooltipContext) {
      super.m_7373_(itemStack, world, tooltip, tooltipContext);
      tooltip.add(Component.m_237115_("tooltip.chestcavity.creeper_fuse").m_130940_(ChatFormatting.ITALIC));
      tooltip.add(Component.m_237115_("tooltip.chestcavity.creeper_fuse_secondary").m_130940_(ChatFormatting.ITALIC));
   }
}
