package net.tigereye.chestcavity.chestcavities.instance;

import java.util.HashMap;
import java.util.Map;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.tigereye.chestcavity.ChestCavity;
import net.tigereye.chestcavity.chestcavities.types.ChestCavityType;
import net.tigereye.chestcavity.chestcavities.types.FallbackChestCavityType;
import net.tigereye.chestcavity.chestcavities.types.json.GeneratedChestCavityAssignmentManager;
import net.tigereye.chestcavity.chestcavities.types.json.GeneratedChestCavityTypeManager;

public class ChestCavityInstanceFactory {
    private static final Map<ResourceLocation, ChestCavityType> entityIdentifierMap = new HashMap<>();
    private static final ChestCavityType FALLBACK_CHEST_CAVITY_TYPE = new FallbackChestCavityType();

    public static ChestCavityType getAssignedType(ResourceLocation entityId) {
        var id = GeneratedChestCavityAssignmentManager.GeneratedChestCavityAssignments.get(entityId);
        var type = id == null ? null : GeneratedChestCavityTypeManager.GeneratedChestCavityTypes.get(id);
        return type != null ? type : entityIdentifierMap.get(entityId);
    }

    public static ChestCavityType getAssignedType(EntityType<?> entityType) {
        return getAssignedType(BuiltInRegistries.f_256780_.m_7981_(entityType));
    }

    public static ChestCavityInstance newChestCavityInstance(EntityType<? extends LivingEntity> type, LivingEntity owner) {
        ChestCavityType profile = getAssignedType(type);
        if (profile == null) {
            ResourceLocation defaultId = ResourceLocation.m_135820_(ChestCavity.config.DEFAULT_CHEST_CAVITY);
            profile = defaultId == null ? null : GeneratedChestCavityTypeManager.GeneratedChestCavityTypes.get(defaultId);
            if (profile == null) profile = FALLBACK_CHEST_CAVITY_TYPE;
        }
        return new ChestCavityInstance(profile, owner);
    }

    public static void register(EntityType<? extends LivingEntity> type, ChestCavityType profile) {
        register(BuiltInRegistries.f_256780_.m_7981_(type), profile);
    }

    public static void register(ResourceLocation id, ChestCavityType profile) {
        entityIdentifierMap.put(id, profile);
    }
}
