package net.tigereye.chestcavity.registration;

import java.util.List;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.event.OnDatapackSyncEvent;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkDirection;
import net.minecraftforge.network.NetworkRegistry;
import net.minecraftforge.network.PacketDistributor;
import net.minecraftforge.network.simple.SimpleChannel;
import net.tigereye.chestcavity.ChestCavity;
import net.tigereye.chestcavity.forge.client.ClientPackets;
import net.tigereye.chestcavity.interfaces.ChestCavityEntity;
import net.tigereye.chestcavity.listeners.OrganActivationListeners;
import net.tigereye.chestcavity.util.NetworkUtil;

public final class CCNetworkingPackets {
    private static final String PROTOCOL = "1";
    private static final int MAX_DATA_SIZE = 1024 * 1024;
    private static final SimpleChannel CHANNEL = NetworkRegistry.newSimpleChannel(ChestCavity.id("main"),
        () -> PROTOCOL, PROTOCOL::equals, PROTOCOL::equals);

    public record Update(byte[] payload) {}
    public record OrganTable(byte[] payload) {}
    public record Hotkey(ResourceLocation ability) {}

    public static void register() {
        CHANNEL.messageBuilder(Update.class, 0, NetworkDirection.PLAY_TO_CLIENT)
            .encoder((message, buffer) -> write(buffer, message.payload()))
            .decoder(buffer -> new Update(read(buffer)))
            .consumerMainThread((message, context) -> DistExecutor.unsafeRunWhenOn(Dist.CLIENT,
                 () -> () -> ClientPackets.update(message.payload()))).add();

        CHANNEL.messageBuilder(OrganTable.class, 1, NetworkDirection.PLAY_TO_CLIENT)
            .encoder((message, buffer) -> write(buffer, message.payload()))
            .decoder(buffer -> new OrganTable(read(buffer)))
            .consumerMainThread((message, context) -> DistExecutor.unsafeRunWhenOn(Dist.CLIENT,
                 () -> () -> ClientPackets.organs(message.payload()))).add();

        CHANNEL.messageBuilder(Hotkey.class, 2, NetworkDirection.PLAY_TO_SERVER)
            .encoder((message, buffer) -> buffer.m_130085_(message.ability()))
            .decoder(buffer -> new Hotkey(buffer.m_130281_()))
            .consumerMainThread((message, context) -> ChestCavityEntity.of(context.get().getSender())
                .ifPresent(entity -> OrganActivationListeners.activate(message.ability(), entity.getChestCavityInstance()))).add();
    }

    private static void write(FriendlyByteBuf buffer, byte[] bytes) {
        buffer.writeBytes(bytes);
    }

    private static byte[] read(FriendlyByteBuf buffer) {
        int length = buffer.readableBytes();
        if (length > MAX_DATA_SIZE) throw new IllegalArgumentException("Chest Cavity data exceeds the packet limit");
        byte[] bytes = new byte[length];
        buffer.readBytes(bytes);
        return bytes;
    }

    public static void sendUpdate(ServerPlayer player, byte[] payload) {
        CHANNEL.send(PacketDistributor.PLAYER.with(() -> player), new Update(payload));
    }

    public static void sendHotkey(ResourceLocation ability) {
        CHANNEL.sendToServer(new Hotkey(ability));
    }

    public static void syncOrgans(OnDatapackSyncEvent event) {
        byte[] payload = NetworkUtil.writeOrganData();
        List<ServerPlayer> recipients = event.getPlayer() == null ? event.getPlayers() : List.of(event.getPlayer());
        for (ServerPlayer player : recipients) {
            CHANNEL.send(PacketDistributor.PLAYER.with(() -> player), new OrganTable(payload));
        }
    }
}
