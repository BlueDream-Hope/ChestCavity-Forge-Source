package net.tigereye.chestcavity.mixin;

import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.LivingEntity;
import net.minecraftforge.common.ForgeHooks;
import net.tigereye.chestcavity.compat.butchery.ButcheryCompat;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(value = ForgeHooks.class, remap = false)
public abstract class ButcheryDeathMixin {
    @Inject(method = "onLivingDeath", at = @At("HEAD"))
    private static void chestcavity$beforeDeath(LivingEntity entity, DamageSource source, CallbackInfoReturnable<Boolean> ci) {
        ButcheryCompat.beforeDeath(entity);
    }

    @Inject(method = "onLivingDeath", at = @At("RETURN"))
    private static void chestcavity$afterDeath(LivingEntity entity, DamageSource source, CallbackInfoReturnable<Boolean> ci) {
        ButcheryCompat.afterDeath(entity);
    }
}
