package net.tigereye.chestcavity.items;

import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;

public final class HeartImplants {
    public static final int MAX_PER_SLOT = 4;

    private HeartImplants() {}

    public static boolean isStackableHeart(ItemStack stack) {
        var item = stack.m_41720_();
        return item == Items.f_42686_ || item == Items.f_42716_;
    }
}
