package net.tigereye.chestcavity.ui;

import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.item.ItemStack;
import net.tigereye.chestcavity.ChestCavity;
import net.tigereye.chestcavity.chestcavities.ChestCavityInventory;
import net.tigereye.chestcavity.items.HeartImplants;

public class ChestCavityScreenHandler extends AbstractContainerMenu {
   private final ChestCavityInventory inventory;
   private final int size;
   private final int rows;

   private static ChestCavityInventory getOrCreateChestCavityInventory(Inventory playerInventory) {
      return new ChestCavityInventory();
   }

   public ChestCavityScreenHandler(int syncId, Inventory playerInventory) {
      this(syncId, playerInventory, getOrCreateChestCavityInventory(playerInventory));
   }

   public ChestCavityScreenHandler(int syncId, Inventory playerInventory, ChestCavityInventory inventory) {
      super(ChestCavity.CHEST_CAVITY_SCREEN_HANDLER, syncId);
      this.size = inventory.m_6643_();
      this.inventory = inventory;
      this.rows = (this.size - 1) / 9 + 1;
      inventory.m_5856_(playerInventory.f_35978_);
      int i = (this.rows - 4) * 18;

      for (int n = 0; n < this.rows; n++) {
         for (int m = 0; m < 9 && n * 9 + m < this.size; m++) {
            this.m_38897_(new ImplantSlot(inventory, m + n * 9, 8 + m * 18, 18 + n * 18));
         }
      }

      for (int var7 = 0; var7 < 3; var7++) {
         for (int m = 0; m < 9; m++) {
            this.m_38897_(new Slot(playerInventory, m + var7 * 9 + 9, 8 + m * 18, 102 + var7 * 18 + i));
         }
      }

      for (int var8 = 0; var8 < 9; var8++) {
         this.m_38897_(new Slot(playerInventory, var8, 8 + var8 * 18, 160 + i));
      }
   }

   public ItemStack m_7648_(Player player, int invSlot) {
      ItemStack newStack = ItemStack.f_41583_;
      Slot slot = (Slot)this.f_38839_.get(invSlot);
      if (slot != null && slot.m_6657_()) {
         ItemStack originalStack = slot.m_7993_();
         newStack = originalStack.m_41777_();
         if (invSlot < this.inventory.m_6643_()) {
            if (!this.m_38903_(originalStack, this.inventory.m_6643_(), this.f_38839_.size(), true)) {
               return ItemStack.f_41583_;
            }
         } else if (!moveIntoChestCavity(originalStack)) {
            return ItemStack.f_41583_;
         }

         if (originalStack.m_41619_()) {
            slot.m_5852_(ItemStack.f_41583_);
         } else {
            slot.m_6654_();
         }
      }

      return newStack;
   }

   public boolean m_6875_(Player player) {
      return this.inventory.m_6542_(player);
   }

   private boolean moveIntoChestCavity(ItemStack stack) {
      if (!HeartImplants.isStackableHeart(stack)) return this.m_38903_(stack, 0, size, false);

      // Forge 1.20.1's quick-move helper uses the slot's item-independent limit.
      int before = stack.m_41613_();
      for (int index = 0; index < size && !stack.m_41619_(); index++) {
         Slot slot = this.f_38839_.get(index);
         if (slot.m_6657_()) slot.m_150659_(stack);
      }
      for (int index = 0; index < size && !stack.m_41619_(); index++) {
         Slot slot = this.f_38839_.get(index);
         if (!slot.m_6657_()) {
            slot.m_150659_(stack);
            break;
         }
      }
      return stack.m_41613_() != before;
   }

   private static final class ImplantSlot extends Slot {
      private ImplantSlot(ChestCavityInventory inventory, int index, int x, int y) {
         super(inventory, index, x, y);
      }

      @Override
      public int m_5866_(ItemStack stack) {
         int limit = super.m_5866_(stack);
         return HeartImplants.isStackableHeart(stack) ? Math.min(limit, HeartImplants.MAX_PER_SLOT) : limit;
      }

      @Override
      public ItemStack m_150656_(ItemStack stack, int count) {
         // Older saves may still contain an oversized stack that the player can take out.
         if (HeartImplants.isStackableHeart(stack) && this.m_7993_().m_41613_() >= this.m_5866_(stack)) return stack;
         return super.m_150656_(stack, count);
      }
   }
}
