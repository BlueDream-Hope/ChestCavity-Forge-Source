package net.tigereye.chestcavity.registration;

import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.commands.arguments.EntityArgument;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.Entity;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.tigereye.chestcavity.interfaces.ChestCavityEntity;
import net.tigereye.chestcavity.util.ChestCavityUtil;

public final class CCCommands {
    public static void register(RegisterCommandsEvent event) {
        event.getDispatcher().register(Commands.m_82127_("chestcavity")
            .then(Commands.m_82127_("getscores")
                .executes(context -> scores(context.getSource(), context.getSource().m_81374_()))
                .then(Commands.m_82129_("entity", EntityArgument.m_91449_())
                    .executes(context -> scores(context.getSource(), EntityArgument.m_91452_(context, "entity")))))
            .then(Commands.m_82127_("resetChestCavity")
                .requires(source -> source.m_6761_(2))
                .executes(context -> reset(context.getSource().m_81374_()))
                .then(Commands.m_82129_("entity", EntityArgument.m_91449_())
                    .executes(context -> reset(EntityArgument.m_91452_(context, "entity"))))));
    }

    private static int scores(CommandSourceStack source, Entity target) {
        return ChestCavityEntity.of(target).map(entity -> {
            ChestCavityUtil.outputOrganScoresString(message -> source.m_288197_(() ->
                Component.m_237113_(message), false), entity.getChestCavityInstance());
            return 1;
        }).orElse(0);
    }

    private static int reset(Entity target) {
        return ChestCavityEntity.of(target).map(entity -> {
            ChestCavityUtil.generateChestCavityIfOpened(entity.getChestCavityInstance());
            return 1;
        }).orElse(0);
    }
}
