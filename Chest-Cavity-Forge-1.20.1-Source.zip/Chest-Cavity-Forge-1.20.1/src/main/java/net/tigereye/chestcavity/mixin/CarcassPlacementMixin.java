package net.tigereye.chestcavity.mixin;

import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.level.block.state.BlockState;
import net.tigereye.chestcavity.compat.butchery.ButcheryCompat;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(BlockItem.class)
public abstract class CarcassPlacementMixin {
    @Inject(method = "m_7429_", at = @At("RETURN"), remap = false)
    private void chestcavity$placeCarcass(BlockPlaceContext context, BlockState state,
            CallbackInfoReturnable<Boolean> ci) {
        if (ci.getReturnValueZ() && context.m_43725_() instanceof ServerLevel level) {
            ButcheryCompat.onCarcassPlaced(level, context.m_8083_(), context.m_43722_(), state);
        }
    }
}
