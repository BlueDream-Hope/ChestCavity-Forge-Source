package net.tigereye.chestcavity.forge.client;

import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.screens.MenuScreens;
import net.minecraftforge.client.ConfigScreenHandler.ConfigScreenFactory;
import net.minecraftforge.client.event.RegisterKeyMappingsEvent;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.ModLoadingContext;
import net.minecraftforge.fml.event.lifecycle.FMLClientSetupEvent;
import me.shedaniel.autoconfig.AutoConfig;
import net.tigereye.chestcavity.ChestCavity;
import net.tigereye.chestcavity.config.CCConfig;
import net.tigereye.chestcavity.forge.CallbackEvent;
import net.tigereye.chestcavity.listeners.KeybindingClientListeners;
import net.tigereye.chestcavity.registration.CCKeybindings;
import net.tigereye.chestcavity.ui.ChestCavityScreen;

public final class ClientEvents {
    public interface EndTick {
        void onEndTick(Minecraft minecraft);
    }

    public static final CallbackEvent<EndTick> END_CLIENT_TICK = CallbackEvent.createArrayBacked(EndTick.class,
        listeners -> minecraft -> {
            for (EndTick listener : listeners) listener.onEndTick(minecraft);
        });
    private static RegisterKeyMappingsEvent keyEvent;

    public static void install(IEventBus modBus) {
        modBus.addListener(ClientEvents::registerKeys);
        modBus.addListener(ClientEvents::setupScreen);
        MinecraftForge.EVENT_BUS.addListener(ClientEvents::clientTick);
        ModLoadingContext.get().registerExtensionPoint(ConfigScreenFactory.class, () ->
            new ConfigScreenFactory((minecraft, parent) -> AutoConfig.getConfigScreen(CCConfig.class, parent).get()));
    }

    private static void registerKeys(RegisterKeyMappingsEvent event) {
        keyEvent = event;
        try {
            CCKeybindings.register();
            KeybindingClientListeners.register();
        } finally {
            keyEvent = null;
        }
    }

    public static KeyMapping registerKeyBinding(KeyMapping key) {
        keyEvent.register(key);
        return key;
    }

    private static void setupScreen(FMLClientSetupEvent event) {
        event.enqueueWork(() -> MenuScreens.m_96206_(ChestCavity.CHEST_CAVITY_SCREEN_HANDLER, ChestCavityScreen::new));
    }

    private static void clientTick(TickEvent.ClientTickEvent event) {
        if (event.phase == TickEvent.Phase.END) END_CLIENT_TICK.invoker().onEndTick(Minecraft.m_91087_());
    }
}
