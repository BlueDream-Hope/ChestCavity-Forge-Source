package net.tigereye.chestcavity.items;

import net.minecraft.network.chat.Component;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.SimpleMenuProvider;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.tigereye.chestcavity.chestcavities.instance.ChestCavityInstanceFactory;
import net.tigereye.chestcavity.compat.butchery.ButcheryCompat;
import net.tigereye.chestcavity.interfaces.ChestCavityEntity;
import net.tigereye.chestcavity.registration.CCItems;
import net.tigereye.chestcavity.registration.CCOrganScores;
import net.tigereye.chestcavity.ui.ChestCavityScreenHandler;
import net.tigereye.chestcavity.util.ChestCavityUtil;

public class ChestOpener extends Item {
    public ChestOpener() {
        super(CCItems.CHEST_OPENER_SETTINGS);
    }

    @Override
    public InteractionResultHolder<ItemStack> m_7203_(Level level, Player player, InteractionHand hand) {
        return openChestCavity(player, player, false)
            ? InteractionResultHolder.m_19092_(player.m_21120_(hand), level.m_5776_())
            : InteractionResultHolder.m_19098_(player.m_21120_(hand));
    }

    public boolean openChestCavity(Player player, LivingEntity target) {
        return openChestCavity(player, target, true);
    }

    public static boolean isRestricted(Player player, LivingEntity target) {
        if (target instanceof Player) return false;
        String message = ChestCavityInstanceFactory.getAssignedType(target.m_6095_()) == null
            ? "message.chestcavity.unsupported_entity"
            : ButcheryCompat.handles(target) ? "message.chestcavity.butchery_required" : null;
        if (message == null) return false;
        player.m_5661_(Component.m_237115_(message), true);
        return true;
    }

    public boolean openChestCavity(Player player, LivingEntity target, boolean shouldKnockback) {
        if (player.m_9236_().m_5776_()) return true;
        if (isRestricted(player, target)) return false;

        var cavity = ChestCavityEntity.of(target).map(ChestCavityEntity::getChestCavityInstance).orElse(null);
        if (cavity == null) return false;
        if (target != player && !cavity.getChestCavityType().isOpenable(cavity)) {
            String reason = !target.m_6844_(EquipmentSlot.CHEST).m_41619_()
                ? "message.chestcavity.obstructed" : "message.chestcavity.too_healthy";
            player.m_5661_(Component.m_237115_(reason), true);
            return false;
        }

        if (cavity.getOrganScore(CCOrganScores.EASE_OF_ACCESS) <= 0) {
            var source = shouldKnockback ? player.m_269291_().m_269075_(player) : player.m_269291_().m_269264_();
            target.m_6469_(source, 4.0f);
        } else {
            player.m_6330_(SoundEvents.f_11749_, SoundSource.PLAYERS, 0.75f, 1.0f);
        }

        if (target.m_6084_()) {
            var inventory = ChestCavityUtil.openChestCavity(cavity);
            ((ChestCavityEntity) player).getChestCavityInstance().ccBeingOpened = cavity;
            player.m_5893_(new SimpleMenuProvider((id, playerInventory, owner) ->
                new ChestCavityScreenHandler(id, playerInventory, inventory),
                Component.m_237110_("screen.chestcavity.title", target.m_5446_())));
        }
        return true;
    }
}
