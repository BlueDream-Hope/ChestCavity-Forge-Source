package net.tigereye.chestcavity.forge;

import net.minecraft.world.level.ItemLike;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.crafting.RecipeType;
import net.minecraftforge.common.ForgeHooks;

public interface FurnaceFuel {
    FurnaceFuel INSTANCE = item -> {
        int ticks = ForgeHooks.getBurnTime(new ItemStack(item), RecipeType.f_44108_);
        return ticks > 0 ? ticks : null;
    };

    Object get(ItemLike item);
}
