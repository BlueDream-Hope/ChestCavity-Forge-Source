package net.tigereye.chestcavity.loot.condition;

import com.google.gson.JsonDeserializationContext;
import com.google.gson.JsonObject;
import com.google.gson.JsonSerializationContext;
import net.minecraft.world.level.storage.loot.LootContext;
import net.minecraft.world.level.storage.loot.parameters.LootContextParams;
import net.minecraft.world.level.storage.loot.predicates.LootItemCondition;
import net.minecraft.world.level.storage.loot.predicates.LootItemConditionType;
import net.minecraft.world.level.storage.loot.predicates.LootItemCondition.Builder;
import net.minecraft.world.entity.LivingEntity;
import net.tigereye.chestcavity.chestcavities.instance.ChestCavityInstanceFactory;
import net.tigereye.chestcavity.compat.butchery.ButcheryCompat;
import net.tigereye.chestcavity.interfaces.ChestCavityEntity;
import net.tigereye.chestcavity.registration.CCLootConditionTypes;

public class ChestCavityUnopenedLootCondition implements LootItemCondition {
   public LootItemConditionType m_7940_() {
      return CCLootConditionTypes.CHEST_CAVITY_UNOPENED;
   }

   public boolean test(LootContext lootContext) {
      return lootContext.m_78953_(LootContextParams.f_81455_) instanceof LivingEntity living
          && living instanceof ChestCavityEntity cavity
          && ChestCavityInstanceFactory.getAssignedType(living.m_6095_()) != null
          && !cavity.getChestCavityInstance().opened
          && !ButcheryCompat.movedToButchery(living);
   }

   public static Builder builder(net.minecraft.advancements.critereon.ItemPredicate.Builder predicate) {
      return ChestCavityUnopenedLootCondition::new;
   }

   public static class Serializer implements net.minecraft.world.level.storage.loot.Serializer<ChestCavityUnopenedLootCondition> {
      public void m_6170_(JsonObject jsonObject, ChestCavityUnopenedLootCondition valueCheckLootCondition, JsonSerializationContext jsonSerializationContext) {
      }

      public ChestCavityUnopenedLootCondition m_7561_(JsonObject jsonObject, JsonDeserializationContext jsonDeserializationContext) {
         return new ChestCavityUnopenedLootCondition();
      }
   }
}
